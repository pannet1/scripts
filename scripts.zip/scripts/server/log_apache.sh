#!/bin/sh
cd /var/log
sudo multitail ispconfig/httpd/*/error.log
cd
