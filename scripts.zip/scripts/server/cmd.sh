sudo netselect-apt
