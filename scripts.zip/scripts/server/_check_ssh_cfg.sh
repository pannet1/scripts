sshd -T
