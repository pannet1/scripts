# sudo apt-get install clamav clamav-daemon clamtk
sudo systemctl stop clamav-freshclam.service
sudo freshclam
sudo systemctl start clamav-freshclam.service
echo "sudo clamscan -r /folder/to/scan/ | grep FOUND >> /path/to/save/report/myfile.txt"
