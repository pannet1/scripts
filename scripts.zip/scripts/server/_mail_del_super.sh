sudo postsuper -d ALL
