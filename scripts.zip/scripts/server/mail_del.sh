#!/bin/sh
sudo su; > /var/spool/mail/root;
mail;
exit
