#!/bin/sh
systemctl status 
