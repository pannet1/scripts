#!/bin/sh
systemctl list-unit-files state=failed
