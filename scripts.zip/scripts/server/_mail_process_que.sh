#!/bin/sh
postqueue -f
