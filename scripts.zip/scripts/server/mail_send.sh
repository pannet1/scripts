#!/bin/sh	
nc -C server1.ecomsense.in 25 < mail_body.txt
