/etc/init.d/clamav-freshclam stop
freshclam
/etc/init.d/clamav-freshclam start
