ispconfig_update.sh
apt-get update -y  && apt-get upgrade -y  && apt-get autoremove && apt-get autoclean
