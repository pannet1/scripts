curl -s http://kkk.ecomsense.in/mbox > curl.log
