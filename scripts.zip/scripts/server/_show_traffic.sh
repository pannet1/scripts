tcpdump
netstat
sockstat
vnstat
iftop
