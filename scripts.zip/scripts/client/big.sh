#!/bin/bash
cd ~/miniconda3/envs/bigpy39
conda activate bigpy39
