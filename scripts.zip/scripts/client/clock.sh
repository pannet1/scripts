xclock -update 1 -bg pink -fg red -hl blue -hd blue -sharp -chime &
