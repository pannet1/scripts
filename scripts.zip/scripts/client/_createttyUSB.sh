#!/bin/bash
mknod /dev/ttyUSB0 c 188 0
