#!/bin/bash

for h in $(seq 437 450); do history -d 437; do
