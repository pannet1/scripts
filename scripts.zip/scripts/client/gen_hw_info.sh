inxi -FAZ --no-host | eos-sendlog
