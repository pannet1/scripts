git config credential.helper store
git push https://github.com/pannet1/$1.git
