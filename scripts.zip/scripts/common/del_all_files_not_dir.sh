find . -name '*.*' -delete
